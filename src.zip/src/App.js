import React, { Component } from "react";
import ReactHighcharts from "react-highcharts/ReactHighstock.src";
import moment from "moment";
import priceData from "./assets/btcdata.json";
export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = { dataPoints: [], isLoaded: false };
  }
  componentDidMount() {
    fetch(
      "https://www.alphavantage.co/query?function=TIME_SERIES_MONTHLY&symbol=GOOGL&apikey=OQ63TSUZFNQJG6NT"
    )
      .then((res) => res.json())
      .then((data) => {
        console.log("The logged data", data["Monthly Time Series"]);
        var dps = [];
        let temp_data = Object.keys(data["Monthly Time Series"]);
        let temp_data2 = Object.values(data["Monthly Time Series"]);
        for (var i = 0; i < temp_data.length; i++) {
          dps.push([new Date(temp_data[i]), Number(temp_data2[i]["4. close"])]);
        }
        console.log(dps);
        console.log(priceData);
        this.setState({
          isLoaded: true,
          dataPoints: dps
        });
      });
  }

  render() {
    const options = { style: "currency", currency: "USD" };
    const numberFormat = new Intl.NumberFormat("en-US", options);
    const configPrice = {
      yAxis: [
        {
          offset: 20,

          labels: {
            formatter: function () {
              return numberFormat.format(this.value);
            },
            x: -15,
            style: {
              color: "#000",
              position: "absolute"
            },
            align: "left"
          }
        }
      ],
      tooltip: {
        shared: true,
        formatter: function () {
          return (
            numberFormat.format(this.y, 0) +
            "</b><br/>" +
            moment(this.x).format("MMMM Do YYYY, h:mm")
          );
        }
      },
      plotOptions: {
        series: {
          showInNavigator: true,
          gapSize: 6
        }
      },
      rangeSelector: {
        selected: 1
      },
      title: {
        text: ` stock price`
      },
      chart: {
        height: 600
      },

      credits: {
        enabled: false
      },

      legend: {
        enabled: true
      },
      xAxis: {
        type: "date"
      },
      rangeSelector: {
        buttons: [
          {
            type: "day",
            count: 1,
            text: "1d"
          },
          {
            type: "day",
            count: 7,
            text: "7d"
          },
          {
            type: "month",
            count: 1,
            text: "1m"
          },
          {
            type: "month",
            count: 3,
            text: "3m"
          },
          {
            type: "all",
            text: "All"
          }
        ],
        selected: 4
      },
      series: [
        {
          name: "Price",
          type: "spline",

          data: this.state.dataPoints,
          tooltip: {
            valueDecimals: 2
          }
        }
      ]
    };
    return (
      <div>
        <div>
          {this.state.isLoaded && (
            <ReactHighcharts config={configPrice}></ReactHighcharts>
          )}
        </div>
      </div>
    );
  }
}